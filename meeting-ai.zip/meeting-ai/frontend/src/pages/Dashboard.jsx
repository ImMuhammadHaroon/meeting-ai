import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { meetingsAPI } from '../services/api';
import { supabase } from '../services/supabase';

const Dashboard = () => {
    const [meetings, setMeetings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        fetchMeetings();
    }, []);

    const fetchMeetings = async () => {
        try {
            const data = await meetingsAPI.getAll();
            setMeetings(data.meetings || []);
        } catch (error) {
            console.error('Failed to fetch meetings:', error);
            setError('Failed to load meetings');
        } finally {
            setLoading(false);
        }
    };

    const handleSignOut = async () => {
        try {
            await supabase.auth.signOut();
            navigate('/signin');
        } catch (error) {
            console.error('Sign out error:', error);
        }
    };

    return (
        <div className="min-h-screen bg-black p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-4xl font-bold text-gradient">Meeting AI</h1>
                    <div className="flex gap-4">
                        <Link to="/create-meeting" className="btn-primary">
                            + Create Meeting
                        </Link>
                        <button onClick={handleSignOut} className="btn-secondary">
                            Sign Out
                        </button>
                    </div>
                </div>

                {/* Error Message */}
                {error && (
                    <div className="mb-4 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-200">
                        {error}
                    </div>
                )}

                {/* Loading State */}
                {loading ? (
                    <div className="text-center py-12">
                        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
                        <p className="mt-4 text-white/60">Loading meetings...</p>
                    </div>
                ) : meetings.length === 0 ? (
                    /* Empty State */
                    <div className="glass-container p-12 text-center">
                        <h2 className="text-2xl font-semibold mb-4">No meetings yet</h2>
                        <p className="text-white/60 mb-6">
                            Create your first meeting to get started with AI-powered transcription and analysis.
                        </p>
                        <Link to="/create-meeting" className="btn-primary inline-block">
                            Create Your First Meeting
                        </Link>
                    </div>
                ) : (
                    /* Meetings Grid */
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {meetings.map((meeting) => (
                            <Link
                                key={meeting.id}
                                to={`/meetings/${meeting.id}`}
                                className="card-glass group"
                            >
                                <div className="flex items-start justify-between mb-3">
                                    <h3 className="text-xl font-semibold group-hover:text-white/90">
                                        {meeting.title}
                                    </h3>
                                    <span
                                        className={`px-2 py-1 text-xs rounded-full ${meeting.processed
                                                ? 'bg-green-500/20 text-green-300'
                                                : 'bg-yellow-500/20 text-yellow-300'
                                            }`}
                                    >
                                        {meeting.processed ? 'Processed' : 'Pending'}
                                    </span>
                                </div>

                                {meeting.description && (
                                    <p className="text-white/60 text-sm mb-4 line-clamp-2">
                                        {meeting.description}
                                    </p>
                                )}

                                <div className="flex items-center justify-between text-sm text-white/50">
                                    <span>{new Date(meeting.created_at).toLocaleDateString()}</span>
                                    <span className="group-hover:text-white/70 transition-colors">
                                        View Details →
                                    </span>
                                </div>
                            </Link>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Dashboard;
