import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { meetingsAPI } from '../services/api';
import Chatbot from '../components/Chatbot';

const MeetingDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [meeting, setMeeting] = useState(null);
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [processingStatus, setProcessingStatus] = useState(null);

    useEffect(() => {
        fetchMeetingDetails();

        // Poll for processing status if not processed
        const interval = setInterval(() => {
            checkProcessingStatus();
        }, 5000);

        return () => clearInterval(interval);
    }, [id]);

    const fetchMeetingDetails = async () => {
        try {
            const data = await meetingsAPI.getById(id);
            setMeeting(data.meeting);
            setTasks(data.tasks || []);
            setLoading(false);
        } catch (error) {
            console.error('Failed to fetch meeting:', error);
            setError('Failed to load meeting details');
            setLoading(false);
        }
    };

    const checkProcessingStatus = async () => {
        try {
            const status = await meetingsAPI.getStatus(id);
            setProcessingStatus(status);

            // Refresh data if newly processed
            if (status.processed && !meeting?.processed) {
                fetchMeetingDetails();
            }
        } catch (error) {
            console.error('Failed to check status:', error);
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-black flex items-center justify-center">
                <div className="text-center">
                    <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
                    <p className="mt-4 text-white/60">Loading meeting...</p>
                </div>
            </div>
        );
    }

    if (error || !meeting) {
        return (
            <div className="min-h-screen bg-black p-6">
                <div className="max-w-4xl mx-auto">
                    <div className="glass-container p-8 text-center">
                        <p className="text-red-400 mb-4">{error || 'Meeting not found'}</p>
                        <button onClick={() => navigate('/dashboard')} className="btn-primary">
                            Back to Dashboard
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-black p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-6">
                    <button
                        onClick={() => navigate('/dashboard')}
                        className="text-white/60 hover:text-white transition-colors mb-4"
                    >
                        ← Back to Dashboard
                    </button>
                    <div className="flex items-start justify-between">
                        <div>
                            <h1 className="text-4xl font-bold text-gradient mb-2">{meeting.title}</h1>
                            {meeting.description && (
                                <p className="text-white/60">{meeting.description}</p>
                            )}
                        </div>
                        <span
                            className={`px-3 py-1 rounded-full text-sm ${meeting.processed
                                    ? 'bg-green-500/20 text-green-300'
                                    : 'bg-yellow-500/20 text-yellow-300'
                                }`}
                        >
                            {meeting.processed ? 'Processed' : 'Processing...'}
                        </span>
                    </div>
                </div>

                {/* Processing Status */}
                {!meeting.processed && processingStatus && (
                    <div className="glass-container p-4 mb-6">
                        <div className="flex items-center gap-3">
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-solid border-white border-r-transparent"></div>
                            <span className="text-white/80">
                                Processing meeting audio... This may take a few minutes.
                            </span>
                        </div>
                    </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Main Content */}
                    <div className="lg:col-span-2 space-y-6">
                        {/* Transcript */}
                        <div className="glass-container p-6">
                            <h2 className="text-2xl font-semibold mb-4">Transcript</h2>
                            {meeting.transcript ? (
                                <div className="bg-white/5 rounded-lg p-4 max-h-96 overflow-y-auto">
                                    <p className="text-white/80 whitespace-pre-wrap">{meeting.transcript}</p>
                                </div>
                            ) : (
                                <p className="text-white/50">
                                    {meeting.processed ? 'No transcript available' : 'Transcript will appear here after processing...'}
                                </p>
                            )}
                        </div>

                        {/* Meeting Notes */}
                        <div className="glass-container p-6">
                            <h2 className="text-2xl font-semibold mb-4">Meeting Notes</h2>
                            {meeting.notes ? (
                                <div className="bg-white/5 rounded-lg p-4 max-h-96 overflow-y-auto">
                                    <div className="text-white/80 whitespace-pre-wrap prose prose-invert max-w-none">
                                        {meeting.notes}
                                    </div>
                                </div>
                            ) : (
                                <p className="text-white/50">
                                    {meeting.processed ? 'No notes available' : 'Notes will appear here after processing...'}
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Sidebar */}
                    <div className="space-y-6">
                        {/* Tasks */}
                        <div className="glass-container p-6">
                            <h2 className="text-xl font-semibold mb-4">Tasks</h2>
                            {tasks.length > 0 ? (
                                <ul className="space-y-3">
                                    {tasks.map((task) => (
                                        <li key={task.id} className="bg-white/5 rounded-lg p-3">
                                            <p className="text-white/90 text-sm mb-1">{task.title}</p>
                                            {task.assignee_id && (
                                                <p className="text-white/50 text-xs">Assigned to: {task.assignee_id}</p>
                                            )}
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-white/50 text-sm">
                                    {meeting.processed ? 'No tasks extracted' : 'Tasks will appear after processing...'}
                                </p>
                            )}
                        </div>

                        {/* Meeting Info */}
                        <div className="glass-container p-6">
                            <h2 className="text-xl font-semibold mb-4">Meeting Info</h2>
                            <div className="space-y-2 text-sm">
                                <div>
                                    <span className="text-white/50">Created:</span>
                                    <p className="text-white/90">
                                        {new Date(meeting.created_at).toLocaleString()}
                                    </p>
                                </div>
                                <div>
                                    <span className="text-white/50">Participants:</span>
                                    <p className="text-white/90">
                                        {meeting.meeting_participants?.length || 0}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Chatbot */}
                {meeting.processed && (
                    <div className="mt-6">
                        <Chatbot meetingId={id} />
                    </div>
                )}
            </div>
        </div>
    );
};

export default MeetingDetail;
