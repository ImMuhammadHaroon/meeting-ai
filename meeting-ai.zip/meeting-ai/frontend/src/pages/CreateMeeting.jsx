import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { meetingsAPI, usersAPI } from '../services/api';

const CreateMeeting = () => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [participants, setParticipants] = useState([]);
    const [selectedParticipants, setSelectedParticipants] = useState([]);
    const [audioFiles, setAudioFiles] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [loadingUsers, setLoadingUsers] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        try {
            const data = await usersAPI.getAll();
            setParticipants(data.users || []);
        } catch (error) {
            console.error('Failed to fetch users:', error);
            setError('Failed to load users');
        } finally {
            setLoadingUsers(false);
        }
    };

    const handleParticipantToggle = (userId) => {
        setSelectedParticipants(prev => {
            if (prev.includes(userId)) {
                return prev.filter(id => id !== userId);
            } else {
                if (prev.length >= 10) {
                    setError('Maximum 10 participants allowed');
                    return prev;
                }
                return [...prev, userId];
            }
        });
    };

    const handleFileChange = (e, index) => {
        const file = e.target.files[0];

        if (!file) return;

        // Validate file type
        const allowedTypes = ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/m4a', 'audio/mp4'];
        const isValidType = allowedTypes.includes(file.type) || file.name.match(/\.(mp3|wav|m4a)$/i);

        if (!isValidType) {
            setError('Only MP3, WAV, and M4A files are allowed');
            return;
        }

        // Validate file size (25MB)
        if (file.size > 25 * 1024 * 1024) {
            setError('File size must be less than 25MB');
            return;
        }

        setAudioFiles(prev => {
            const newFiles = [...prev];
            newFiles[index] = file;
            return newFiles;
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            if (!title) {
                throw new Error('Title is required');
            }

            if (selectedParticipants.length === 0) {
                throw new Error('Please select at least one participant');
            }

            if (audioFiles.length !== selectedParticipants.length || audioFiles.some(f => !f)) {
                throw new Error('Please upload audio file for each participant');
            }

            // Create meeting
            const { meeting } = await meetingsAPI.create({
                title,
                description,
                participantIds: selectedParticipants
            });

            // Upload audio files
            await meetingsAPI.uploadAudio(meeting.id, audioFiles, selectedParticipants);

            // Trigger processing
            await meetingsAPI.process(meeting.id);

            // Navigate to meeting detail page
            navigate(`/meetings/${meeting.id}`);
        } catch (error) {
            setError(error.message || 'Failed to create meeting');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-black p-6">
            <div className="max-w-3xl mx-auto">
                <div className="mb-6">
                    <button
                        onClick={() => navigate('/dashboard')}
                        className="text-white/60 hover:text-white transition-colors"
                    >
                        ← Back to Dashboard
                    </button>
                </div>

                <div className="glass-container p-8">
                    <h1 className="text-3xl font-bold mb-6 text-gradient">Create New Meeting</h1>

                    {error && (
                        <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-200 text-sm">
                            {error}
                        </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-6">
                        {/* Title */}
                        <div>
                            <label className="block text-sm font-medium mb-2 text-white/80">
                                Meeting Title *
                            </label>
                            <input
                                type="text"
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                className="input-glass w-full"
                                placeholder="e.g., Q4 Planning Meeting"
                                required
                            />
                        </div>

                        {/* Description */}
                        <div>
                            <label className="block text-sm font-medium mb-2 text-white/80">
                                Description
                            </label>
                            <textarea
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                className="textarea-glass w-full h-24"
                                placeholder="Brief description of the meeting..."
                            />
                        </div>

                        {/* Participants */}
                        <div>
                            <label className="block text-sm font-medium mb-2 text-white/80">
                                Select Participants * (max 10)
                            </label>
                            {loadingUsers ? (
                                <p className="text-white/60 text-sm">Loading users...</p>
                            ) : (
                                <div className="glass-container p-4 max-h-48 overflow-y-auto space-y-2">
                                    {participants.map(user => (
                                        <label
                                            key={user.id}
                                            className="flex items-center gap-3 p-2 rounded hover:bg-white/5 cursor-pointer"
                                        >
                                            <input
                                                type="checkbox"
                                                checked={selectedParticipants.includes(user.id)}
                                                onChange={() => handleParticipantToggle(user.id)}
                                                className="w-4 h-4 accent-white"
                                            />
                                            <span className="text-white/90">{user.fullName}</span>
                                            <span className="text-white/50 text-sm">({user.email})</span>
                                        </label>
                                    ))}
                                </div>
                            )}
                            <p className="text-white/50 text-xs mt-1">
                                {selectedParticipants.length} participant(s) selected
                            </p>
                        </div>

                        {/* Audio Files */}
                        {selectedParticipants.length > 0 && (
                            <div>
                                <label className="block text-sm font-medium mb-2 text-white/80">
                                    Upload Audio Files * (one per participant)
                                </label>
                                <p className="text-white/50 text-xs mb-3">
                                    Supported formats: MP3, WAV, M4A (max 25MB each)
                                </p>
                                <div className="space-y-3">
                                    {selectedParticipants.map((participantId, index) => {
                                        const participant = participants.find(p => p.id === participantId);
                                        return (
                                            <div key={participantId} className="glass-container p-4">
                                                <p className="text-sm text-white/80 mb-2">
                                                    {participant?.fullName || 'Unknown User'}
                                                </p>
                                                <input
                                                    type="file"
                                                    accept=".mp3,.wav,.m4a,audio/mpeg,audio/wav,audio/mp4"
                                                    onChange={(e) => handleFileChange(e, index)}
                                                    className="text-white/70 text-sm file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-white/20 file:text-white file:cursor-pointer hover:file:bg-white/30"
                                                    required
                                                />
                                                {audioFiles[index] && (
                                                    <p className="text-green-400 text-xs mt-1">
                                                        ✓ {audioFiles[index].name}
                                                    </p>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )}

                        {/* Submit Button */}
                        <div className="flex gap-4">
                            <button
                                type="submit"
                                disabled={loading || selectedParticipants.length === 0}
                                className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {loading ? 'Creating Meeting...' : 'Create Meeting'}
                            </button>
                            <button
                                type="button"
                                onClick={() => navigate('/dashboard')}
                                className="btn-secondary"
                            >
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default CreateMeeting;
