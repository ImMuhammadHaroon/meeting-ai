import axios from 'axios';
import { supabase } from './supabase';

const API_URL = import.meta.env.VITE_API_URL;

// Create axios instance
const api = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});

// Add auth token to requests
api.interceptors.request.use(async (config) => {
    const { data: { session } } = await supabase.auth.getSession();

    if (session?.access_token) {
        config.headers.Authorization = `Bearer ${session.access_token}`;
    }

    return config;
});

// Auth API
export const authAPI = {
    signUp: async (email, password, fullName) => {
        const response = await api.post('/auth/signup', { email, password, fullName });
        return response.data;
    },

    signIn: async (email, password) => {
        const response = await api.post('/auth/signin', { email, password });
        return response.data;
    },

    signOut: async () => {
        const response = await api.post('/auth/signout');
        return response.data;
    },

    getCurrentUser: async () => {
        const response = await api.get('/auth/me');
        return response.data;
    }
};

// Users API
export const usersAPI = {
    getAll: async () => {
        const response = await api.get('/users');
        return response.data;
    }
};

// Meetings API
export const meetingsAPI = {
    create: async (meetingData) => {
        const response = await api.post('/meetings', meetingData);
        return response.data;
    },

    getAll: async () => {
        const response = await api.get('/meetings');
        return response.data;
    },

    getById: async (id) => {
        const response = await api.get(`/meetings/${id}`);
        return response.data;
    },

    uploadAudio: async (id, files, participantIds) => {
        const formData = new FormData();
        files.forEach(file => formData.append('audioFiles', file));
        formData.append('participantIds', JSON.stringify(participantIds));

        const response = await api.post(`/meetings/${id}/upload`, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    },

    process: async (id) => {
        const response = await api.post(`/meetings/${id}/process`);
        return response.data;
    },

    getStatus: async (id) => {
        const response = await api.get(`/meetings/${id}/status`);
        return response.data;
    }
};

// Chat API
export const chatAPI = {
    sendMessage: async (meetingId, message) => {
        const response = await api.post(`/meetings/${meetingId}/chat`, { message });
        return response.data;
    },

    getHistory: async (meetingId) => {
        const response = await api.get(`/meetings/${meetingId}/chat/history`);
        return response.data;
    }
};

export default api;
