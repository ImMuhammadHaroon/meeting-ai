import { useState, useEffect, useRef } from 'react';
import { chatAPI } from '../services/api';

const Chatbot = ({ meetingId }) => {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const messagesEndRef = useRef(null);

    useEffect(() => {
        fetchChatHistory();
    }, [meetingId]);

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const fetchChatHistory = async () => {
        try {
            const data = await chatAPI.getHistory(meetingId);
            setMessages(data.chatHistory || []);
        } catch (error) {
            console.error('Failed to fetch chat history:', error);
        }
    };

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!input.trim()) return;

        const userMessage = input.trim();
        setInput('');
        setError('');
        setLoading(true);

        // Add user message to UI immediately
        const tempMessage = {
            id: Date.now(),
            message: userMessage,
            response: '',
            created_at: new Date().toISOString()
        };
        setMessages(prev => [...prev, tempMessage]);

        try {
            const data = await chatAPI.sendMessage(meetingId, userMessage);

            // Update with actual response
            setMessages(prev =>
                prev.map(msg =>
                    msg.id === tempMessage.id
                        ? { ...msg, response: data.response }
                        : msg
                )
            );
        } catch (error) {
            console.error('Chat error:', error);
            setError('Failed to send message');
            // Remove temp message on error
            setMessages(prev => prev.filter(msg => msg.id !== tempMessage.id));
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-black/90 rounded-xl p-6">
            <h2 className="text-2xl font-semibold mb-4">Meeting Assistant</h2>
            <p className="text-white/60 text-sm mb-4">
                Ask questions about the meeting transcript, notes, or tasks.
            </p>

            {/* Chat Messages */}
            <div className="bg-white/5 rounded-lg p-4 h-96 overflow-y-auto mb-4 space-y-4">
                {messages.length === 0 ? (
                    <div className="text-center text-white/50 mt-20">
                        <p>No messages yet. Start a conversation!</p>
                        <p className="text-xs mt-2">Try asking: "What were the key decisions made?"</p>
                    </div>
                ) : (
                    messages.map((msg, index) => (
                        <div key={msg.id || index} className="space-y-2">
                            {/* User Message */}
                            <div className="flex justify-end">
                                <div className="bg-white/20 rounded-lg px-4 py-2 max-w-[80%]">
                                    <p className="text-white/90 text-sm">{msg.message}</p>
                                </div>
                            </div>

                            {/* Bot Response */}
                            {msg.response ? (
                                <div className="flex justify-start">
                                    <div className="bg-white/10 rounded-lg px-4 py-2 max-w-[80%]">
                                        <p className="text-white/80 text-sm whitespace-pre-wrap">{msg.response}</p>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex justify-start">
                                    <div className="bg-white/10 rounded-lg px-4 py-2">
                                        <div className="flex items-center gap-2">
                                            <div className="h-2 w-2 bg-white/60 rounded-full animate-bounce"></div>
                                            <div className="h-2 w-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                                            <div className="h-2 w-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    ))
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Error Message */}
            {error && (
                <div className="mb-3 p-2 bg-red-500/20 border border-red-500/50 rounded text-red-200 text-sm">
                    {error}
                </div>
            )}

            {/* Input Form */}
            <form onSubmit={handleSubmit} className="flex gap-2">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask a question about this meeting..."
                    className="input-glass flex-1"
                    disabled={loading}
                />
                <button
                    type="submit"
                    disabled={loading || !input.trim()}
                    className="btn-primary px-6 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {loading ? 'Sending...' : 'Send'}
                </button>
            </form>
        </div>
    );
};

export default Chatbot;
